class Address:



    def __init__(self,street,number,postalcode,city):
        self.street = street
        self.number = number
        self.postalcode = postalcode
        self.city = city



    def get_address(self):
        return self.street + "  " + str(self.number) + "  " + \
            str(self.postalcode) + "  " + str(self.city)