
from Address import Address

hans_meier = Address("Hauptstrasse", 12, 84347, "Pfarrkirchen")
cordula_senf = Address("Duckegasse", 3, 1220, "Wien")






n=0
while n<5:
    print(n)
    n+=1

from Address import Address

hans_meier = Address("Hauptstrasse", 12, 84347, "Pfarrkirchen")
cordula_senf = Address("Duckegasse", 3, 1220, "Wien")


